import os
import shutil
from sklearn.model_selection import train_test_split

def split_data(source_dir, dest_dir, test_size=0.2):
    # Get the absolute path of the script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Construct absolute paths
    source_dir = os.path.abspath(os.path.join(script_dir, '..', '..', source_dir))
    dest_dir = os.path.abspath(os.path.join(script_dir, '..', '..', dest_dir))

    for category in ['diseased', 'healthy']:
        category_source = os.path.join(source_dir, category)
        
        if not os.path.exists(category_source):
            print(f"Warning: {category_source} does not exist. Skipping.")
            continue

        os.makedirs(os.path.join(dest_dir, 'train', category), exist_ok=True)
        os.makedirs(os.path.join(dest_dir, 'test', category), exist_ok=True)
        
        files = os.listdir(category_source)
        train_files, test_files = train_test_split(files, test_size=test_size, random_state=42)
        
        for file in train_files:
            shutil.copy(os.path.join(category_source, file), 
                        os.path.join(dest_dir, 'train', category, file))
        
        for file in test_files:
            shutil.copy(os.path.join(category_source, file), 
                        os.path.join(dest_dir, 'test', category, file))

if __name__ == "__main__":
    split_data('data/raw', 'data/processed')
    print("Data splitting completed.")
