import tensorflow as tf
from keras.preprocessing import image
import numpy as np
import os

def load_model(model_path):
    return tf.keras.models.load_model(model_path)

def predict_image(model, img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array /= 255.

    prediction = model.predict(img_array)
    return prediction[0][0]

if __name__ == "__main__":
    # Get the directory where the script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Construct the path to the model file
    model_path = os.path.join(script_dir, '..', '..', 'models', 'soybean_disease_detector.h5')
    
    # Check if the model file exists
    if not os.path.exists(model_path):
        print(f"Error: Model file not found at {model_path}")
        print("Please make sure you have trained the model and it's saved in the correct location.")
        exit(1)

    model = load_model(model_path)

    # Ask the user for the image path
    img_path = input("Enter the path to the image you want to predict: ")
    
    # Check if the image file exists
    if not os.path.exists(img_path):
        print(f"Error: Image file not found at {img_path}")
        print("Please make sure you've entered the correct path to the image.")
        exit(1)

    result = predict_image(model, img_path)
    print(f"Probability of disease: {result:.2f}")
