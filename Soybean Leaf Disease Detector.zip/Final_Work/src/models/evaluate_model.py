import tensorflow as tf
import numpy as np
from sklearn.metrics import confusion_matrix, classification_report
import os

def load_model(model_path):
    return tf.keras.models.load_model(model_path)

def load_and_preprocess_data(data_dir, img_size=(224, 224)):
    data_generator = tf.keras.preprocessing.image.ImageDataGenerator(rescale=1./255)
    data = data_generator.flow_from_directory(
        data_dir,
        target_size=img_size,
        batch_size=32,
        class_mode='binary',
        shuffle=False
    )
    return data

def evaluate_model(model, test_data):
    # Get predictions
    predictions = model.predict(test_data)
    predicted_classes = (predictions > 0.5).astype(int)
    true_classes = test_data.classes

    # Compute confusion matrix
    cm = confusion_matrix(true_classes, predicted_classes)

    # Generate classification report
    class_report = classification_report(true_classes, predicted_classes, target_names=['Healthy', 'Diseased'])

    return cm, class_report

if __name__ == "__main__":
    # Get the directory where the script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Construct the path to the model file
    model_path = os.path.join(script_dir, '..', '..', 'models', 'soybean_disease_detector.h5')
    
    # Check if the model file exists
    if not os.path.exists(model_path):
        print(f"Error: Model file not found at {model_path}")
        print("Please make sure you have trained the model and it's saved in the correct location.")
        exit(1)

    # Load the model
    model = load_model(model_path)

    # Load test data
    test_data_dir = os.path.join(script_dir, '..', '..', 'data', 'processed', 'test')
    test_data = load_and_preprocess_data(test_data_dir)

    # Evaluate the model
    cm, class_report = evaluate_model(model, test_data)

    # Print confusion matrix
    print("Confusion Matrix:")
    print(cm)

    # Print classification report
    print("\nClassification Report:")
    print(class_report)
