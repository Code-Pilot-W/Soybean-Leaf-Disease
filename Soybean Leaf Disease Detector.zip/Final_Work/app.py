import os
from flask import Flask, request, render_template, jsonify
import tensorflow as tf
import numpy as np
from keras.preprocessing import image

# Get the absolute path of the current file
current_dir = os.path.dirname(os.path.abspath(__file__))

# Create the Flask app with the template folder explicitly set
app = Flask(__name__, template_folder=os.path.join(current_dir, 'templates'))

# Load the trained model
model_path = os.path.join(current_dir, 'models', 'soybean_disease_detector.h5')
model = tf.keras.models.load_model(model_path)

def predict_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array /= 255.

    prediction = model.predict(img_array)
    return prediction[0][0]

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'})
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No selected file'})
        if file:
            filepath = os.path.join(current_dir, 'uploads', file.filename)
            file.save(filepath)
            result = predict_image(filepath)
            os.remove(filepath)  # Remove the file after prediction
            return jsonify({'result': float(result), 'message': 'Probability of disease'})
    return render_template('upload.html')

if __name__ == '__main__':
    os.makedirs(os.path.join(current_dir, 'uploads'), exist_ok=True)
    app.run(debug=True)
